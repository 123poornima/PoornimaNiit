package com.niit.dao;

import java.util.List;

import com.niit.model.Cart;

public interface CartDAO 
{
  //addcart method declaration
  public void addCart(Cart cart);
  public void deleteCart(int id);
  public Cart getCart(String p_id);
  public List<Cart> list();
  public List<Cart> userCartList(String uname);
  
}
