package com.niit.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.UserDAO;

import com.niit.model.User;

public class UserTest 
{

	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		
		UserDAO userDAO= (UserDAO) context.getBean("userDAO");

		User user=(User) context.getBean("user");
		
		
		user.setName("pooh");
		user.setMailId("pooh@gmail.com");
		user.setPassword("12345");
		user.setAddress("DVG");
		user.setPhoneNo("88676757");
		
		userDAO.addUser(user);
		
		
	}

}
